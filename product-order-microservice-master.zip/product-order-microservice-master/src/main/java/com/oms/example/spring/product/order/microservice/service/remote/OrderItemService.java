package com.szabodev.example.spring.product.order.microservice.service.remote;

import com.szabodev.example.spring.product.order.microservice.dto.OrderItemDTO;

import java.util.List;
import java.util.Optional;

public interface OrderItemService {

    List<OrderItemDTO> findAll();

    Optional<OrderItemDTO> findById(int id);
}
