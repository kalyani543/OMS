package com.oms.example.spring.product.order.microservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

import com.javatpoint.model.String;

import java.io.Serializable;

@Entity
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderItem implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int productCode;

    @Column(nullable = false, unique = true)
    private String productName;

    @Column(nullable = false)
    private int quantity;
    
    public int getProductCode() 
    {
    return productCode;
    }
    public void setProductCode(int productCode) 
    {
    this.productCode = productCode;
    }
    
    public String getProductName() 
    {
    return productName;
    }
    public void setProductName(String productName) 
    {
    this.productName = productName;
    }
    
    public int getQuantity() 
    {
    return quantity;
    }
    public void setQuantity(int quantity) 
    {
    this.quantity = quantity;
    }
}