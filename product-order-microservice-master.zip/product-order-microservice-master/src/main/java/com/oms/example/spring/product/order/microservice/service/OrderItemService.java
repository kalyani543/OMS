package com.oms.example.spring.product.order.microservice.service;


import com.oms.example.spring.product.order.microservice.dto.OrderItemDTO;

import java.util.List;
import java.util.Optional;

public interface OrderItemService {

    Optional<OrderItemDTO> findById(int orderItemId);
}
