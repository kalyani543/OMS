package com.szabodev.example.spring.product.order.microservice.service.remote;

import com.szabodev.example.spring.product.order.microservice.dto.OrderDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrdersItemServiceImpl implements OrdeItemService {

    private final OrderItemServiceClient productServiceClient;

    @Override
    public List<OrderItemDTO> findAll() {
        List<OrderDTO> products = null;
        try {
            products = productServiceClient.findAll(true);
        } catch (RestClientException e) {
            log.error("Cannot get orders", e);
        }
        return products != null ? products : Collections.emptyList();
    }

    @Override
    public Optional<OrderItemDTO> findById(int id) {
        OrderItemDTO product = null;
        try {
        	product = productServiceClient.findById(id);
        } catch (RestClientException e) {
            log.error("Cannot get order", e);
        }
        return Optional.ofNullable(product);
    }
}
