package com.oms.example.spring.product.order.microservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.validation.constraints.NotNull;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderItemDTO {

	@NotNull
    private int orderId;

    @NotNull
    private String customerName;

    @NotNull
    private String orderDate;
    
    @NotNull
    private String shippingAddress;
    
    @NotNull
    private int orderItems;
    
    @NotNull
    private float total;
}
