package com.oms.example.spring.product.order.microservice.service;

import com.oms.example.spring.product.order.microservice.dto.OrderDTO;
import com.oms.example.spring.product.order.microservice.model.Order;
import com.oms.example.spring.product.order.microservice.repository.OrderRepository;
import com.oms.example.spring.product.order.microservice.service.mapper.OrderMapper;
import com.oms.example.spring.product.order.microservice.service.remote.Service;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final OrderRepository productOrderRepository;

    private final OrderMapper productOrderMapper;

    private final OrderService orderService;

    @Override
    public Optional<OrderDTO> findById(int orderID) {
        Optional<Order> byId = productOrderRepository.findById(id);
        return Optional.ofNullable(productOrderMapper.toDTO(byId.orElse(null)));
    }

    @Override
    public Optional<OrderDTO> findByProductId(int id) {
        Optional<ProductOrder> byId = productOrderRepository.findByProductId(id);
        return Optional.ofNullable(productOrderMapper.toDTO(byId.orElse(null)));
    }

    @Override
    public List<ProductOrderDTO> findAll(boolean getProductInfo) {
        List<OrderDTO> productOrders = productOrderMapper.toDTOs((List<Order>) productOrderRepository.findAll());
        productOrders.forEach(order -> orderService.findById(order.getProductCode()).ifPresent(product -> order.setProductName(product.getProductName())));
        return productOrders;
    }

    @Override
    public void deleteById(int id) {
        productOrderRepository.deleteById(id);
    }

    @Override
    public OrderDTO save(OrderDTO productOrder) {
        Order saved = productOrderRepository.save(productOrderMapper.toEntity(productOrder));
        return productOrderMapper.toDTO(saved);
    }
}
