package com.oms.example.spring.product.order.microservice.service.mapper;

import com.oms.example.spring.product.order.microservice.dto.OrderItemDTO;
import com.oms.example.spring.product.order.microservice.model.OrderItem;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface OrderItemMapper {

    OrderItemDTO toDTO(OrderItem orderItem);

    List<OrderItemDTO> toDTOs(List<OrderItem> orderItems);

    OrderItem toEntity(OrderItemDTO orderItemDTO);
}
