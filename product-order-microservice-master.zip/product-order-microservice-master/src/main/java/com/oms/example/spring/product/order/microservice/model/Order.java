package com.oms.example.spring.product.order.microservice.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

import com.javatpoint.model.String;

import java.io.Serializable;

@Entity
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderItem implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderId;

    @Column(nullable = false, unique = true)
    private String customerName;

    @Column(nullable = false)
    private String orderDate;
    
    @Column(nullable = false)
    private String shippingAddress;
    
    @Column(nullable = false)
    private int orderItems;
    
    @Column(nullable = false)
    private float total;
    
    public int getOrderId() 
    {
    return orderId;
    }
    public void setOrderId(int orderId) 
    {
    this.orderId = orderId;
    }
    
    public String getCustomerName() 
    {
    return customerName;
    }
    public void setCustomerName(String customerName) 
    {
    this.customerName = customerName;
    }
    
    public String getOrderDate() 
    {
    return orderDate;
    }
    public void setOrderDate(String orderDate) 
    {
    this.orderDate = orderDate;
    }
    
    public int getOrderItems() 
    {
    return orderItems;
    }
    public void setOrderItems(int orderItems) 
    {
    this.orderItems = orderItems;
    }
    
    public float getTotal() 
    {
    return total;
    }
    public void setTotal(float total) 
    {
    this.total = total;
    }
}