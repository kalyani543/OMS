package com.oms.example.spring.product.order.microservice.service;

import com.oms.example.spring.product.order.microservice.dto.OrderItemDTO;
import com.oms.example.spring.product.order.microservice.model.OrderItem;
import com.oms.example.spring.product.order.microservice.repository.OrderItemRepository;
import com.oms.example.spring.product.order.microservice.service.mapper.OrderItemMapper;
import com.oms.example.spring.product.order.microservice.service.remote.Service;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class OrderItemServiceImpl implements OrderItemService {

    private final OrderItemRepository productOrderRepository;

    private final OrderItemMapper productOrderMapper;

    private final OrderItemService orderService;

    @Override
    public Optional<OrderItemDTO> findById(int orderID) {
        Optional<OrderItem> byId = productOrderRepository.findById(id);
        return Optional.ofNullable(productOrderMapper.toDTO(byId.orElse(null)));
    }

    @Override
    public Optional<OrderItemDTO> findByProductId(int id) {
        Optional<ProductOrder> byId = productOrderRepository.findByProductId(id);
        return Optional.ofNullable(productOrderMapper.toDTO(byId.orElse(null)));
    }

    @Override
    public List<OrderItemDTO> findAll(boolean getProductInfo) {
        List<OrderItemDTO> productOrders = productOrderMapper.toDTOs((List<OrderItem>) productOrderRepository.findAll());
        productOrders.forEach(orderItem -> orderService.findById(orderItem.getProductCode()).ifPresent(product -> order.setProductName(product.getProductName())));
        return productOrders;
    }

    @Override
    public void deleteById(int id) {
        productOrderRepository.deleteById(id);
    }

    @Override
    public OrderDTO save(OrderItemDTO productOrder) {
        Order saved = productOrderRepository.save(productOrderMapper.toEntity(productOrder));
        return productOrderMapper.toDTO(saved);
    }
}
