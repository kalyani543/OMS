package com.szabodev.example.spring.product.order.microservice.service.remote;

import com.szabodev.example.spring.product.order.microservice.dto.OrderDTO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrdersServiceImpl implements OrderService {

    private final OrderServiceClient productServiceClient;

    @Override
    public List<OrderDTO> findAll() {
        List<OrderDTO> products = null;
        try {
            orders = productServiceClient.findAll(true);
        } catch (RestClientException e) {
            log.error("Cannot get orders", e);
        }
        return orders != null ? orders : Collections.emptyList();
    }

    @Override
    public Optional<OrderDTO> findById(int id) {
        OrderDTO order = null;
        try {
            order = productServiceClient.findById(id);
        } catch (RestClientException e) {
            log.error("Cannot get order", e);
        }
        return Optional.ofNullable(order);
    }
}
