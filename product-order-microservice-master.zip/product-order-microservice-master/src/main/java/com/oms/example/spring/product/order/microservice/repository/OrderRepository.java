package com.oms.example.spring.product.order.microservice.repository;

import com.oms.example.spring.product.order.microservice.model.Order;
import com.oms.example.spring.product.order.microservice.model.OrderItem;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface OrderRepository extends CrudRepository<Order, int> {

    Optional<Order> findById(int orderId);
    Optional<Order> findByProductId(int id);
    Optional<List<Order>> findAll(int id);
    Optional<List<Order>> deleteById(int id);
}
