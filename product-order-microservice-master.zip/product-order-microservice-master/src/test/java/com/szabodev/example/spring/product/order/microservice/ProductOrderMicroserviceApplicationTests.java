package com.szabodev.example.spring.product.order.microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductOrderMicroserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
