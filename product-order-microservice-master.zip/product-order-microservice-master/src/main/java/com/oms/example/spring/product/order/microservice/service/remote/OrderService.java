package com.oms.example.spring.product.order.microservice.service;


import com.oms.example.spring.product.order.microservice.dto.OrderDTO;

import java.util.List;
import java.util.Optional;

public interface OrderService {

	    List<OrderDTO> findAll();

	    Optional<OrderDTO> findById(int id);
}
