package com.oms.example.spring.product.order.microservice.service.mapper;

import com.oms.example.spring.product.order.microservice.dto.OrderDTO;
import com.oms.example.spring.product.order.microservice.model.Order;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface OrderMapper {

    OrderDTO toDTO(Order orders);

    List<OrderDTO> toDTOs(List<Order> orders);

    Order toEntity(OrderDTO orderDTO);
}
