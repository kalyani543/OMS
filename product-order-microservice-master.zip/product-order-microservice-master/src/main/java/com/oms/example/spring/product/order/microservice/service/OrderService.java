package com.oms.example.spring.product.order.microservice.service;


import com.oms.example.spring.product.order.microservice.dto.OrderDTO;

import java.util.List;
import java.util.Optional;

public interface OrderService {

    Optional<OrderDTO> findById(int orderId);
}
