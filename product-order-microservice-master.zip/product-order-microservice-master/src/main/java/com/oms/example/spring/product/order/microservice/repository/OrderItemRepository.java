package com.oms.example.spring.product.order.microservice.repository;

import com.oms.example.spring.product.order.microservice.model.OrderItem;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface OrderItemRepository extends CrudRepository<OrderItem, int> {

    Optional<OrderItem> findById(int orderId);
    Optional<OrderItem> findByProductId(int id);
    Optional<List<OrderItem>> findAll(int id);
    Optional<List<OrderItem>> deleteById(int id);
}
